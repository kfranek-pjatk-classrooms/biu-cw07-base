import {Component, Input} from '@angular/core';
import {ContactData} from '../../shared/contact-data.model';

@Component({
  selector: 'contact-list-item',
  templateUrl: './contact-list-item.component.html'
})
export class ContactListItemComponent {
  @Input() public contactData: ContactData;
}
