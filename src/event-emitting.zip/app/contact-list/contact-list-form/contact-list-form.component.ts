import {Component, Input, Output, EventEmitter, OnInit} from '@angular/core';


@Component({
  selector: 'contact-list-form',
  templateUrl: './contact-list-form.component.html'
})
export class ContactListFormComponent implements OnInit {
  @Output() itemCreated = new EventEmitter<{ labelText: string, value: string }>();
  labelText = '';
  value = '';

  ngOnInit() {
  }

  public addNewItem()
  {
    this.itemCreated.emit({
      labelText: this.labelText,
      value: this.value
    });
  }

  updateLabelText(event: Event) {
    this.labelText = (event.target as HTMLInputElement).value;
  }

  updateValue(event: Event) {
    this.value = (event.target as HTMLInputElement).value;
  }
}
