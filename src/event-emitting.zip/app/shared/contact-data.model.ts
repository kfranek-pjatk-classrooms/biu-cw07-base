export class ContactData {
  constructor(public labelText: string, public value: string) {
  }
}
